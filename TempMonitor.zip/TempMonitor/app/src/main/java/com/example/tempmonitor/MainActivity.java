package com.example.tempmonitor;

import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.Collections;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class MainActivity extends AppCompatActivity {

    private TextView tvCurrentTemp;
    private RecyclerView recyclerView;
    private ApiService apiService;

    // Zmienne do odświeżania
    private final Handler handler = new Handler(Looper.getMainLooper());
    private Runnable refreshRunnable;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        tvCurrentTemp = findViewById(R.id.tvCurrentTemp);
        recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl("http://10.0.2.2:8080/") // Adres IP dla emulatora
                .addConverterFactory(GsonConverterFactory.create())
                .build();

        apiService = retrofit.create(ApiService.class);

        // Przygotowanie zadania odświeżania
        refreshRunnable = new Runnable() {
            @Override
            public void run() {
                pobierzDaneZSerwera();
                handler.postDelayed(this, 10000); // Odświeżaj co 10 sekund
            }
        };
    }

    private void pobierzDaneZSerwera() {
        apiService.getWszystkiePomiary().enqueue(new Callback<List<Dane>>() {
            @Override
            public void onResponse(@NonNull Call<List<Dane>> call, @NonNull Response<List<Dane>> response) {
                if (response.isSuccessful() && response.body() != null) {
                    List<Dane> daneList = response.body();
                    if (!daneList.isEmpty()) {
                        Dane ostatni = daneList.get(daneList.size() - 1);
                        tvCurrentTemp.setText(String.format("%d°C", ostatni.getTemperatura()));

                        Collections.reverse(daneList);
                        DaneAdapter adapter = new DaneAdapter(daneList);
                        recyclerView.setAdapter(adapter);
                    }
                } else {
                    Toast.makeText(MainActivity.this, "Błąd serwera: " + response.code(), Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(@NonNull Call<List<Dane>> call, @NonNull Throwable t) {
                Toast.makeText(MainActivity.this, "Błąd połączenia: " + t.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        handler.post(refreshRunnable); // Start odświeżania
    }

    @Override
    protected void onPause() {
        super.onPause();
        handler.removeCallbacks(refreshRunnable); // Stop odświeżania
    }
}
